﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GreatTrade.Models;
using Microsoft.AspNetCore.Mvc;

namespace GreatTrade.Controllers
{
    public class VisualizarController : Controller
    {

        public Great great;
        public IActionResult Index()
        {
            great = new Great();
           // ViewData["Filtrados"] = great.filtarCiudades(ciudad);
            ViewData["Usuarios"] = great.users;
            return View();
        }

        public IActionResult Mostrar(String title, int id)
        {
            great = new Great();

            /*  foreach(User i in great.users)
              {
                 ViewData["Message"]+= "\n" + i.name;
              }*/
            /*foreach (Product i in great.products)
            {
                ViewData["Message"] += "\n" + i.title;
                
            }

            foreach (Product i in great.filtarCiudades(ciudad))
                ViewData["Filtrados"] += "\n"+i.city+ "  "+ i.title;
                
                    */
            
            ViewData["Products"] = great.products;
            ViewData["Photos"] = great.buscarNom(title).photos;
            ViewData["Usuarios"] = great.searchUser(id).name;

            return View(great.buscarNom(title)); 

       
        }


    }
}